import os
import json
import base64
from email.mime.text import MIMEText
import re
from bs4 import BeautifulSoup
from google.oauth2.credentials import Credentials
from googleapiclient.discovery import build

from config import ALL_LABELS

SCOPES = [
    "https://www.googleapis.com/auth/gmail.modify",
    "https://www.googleapis.com/auth/gmail.compose",
]


def load_credentials():
    creds_json = os.getenv("GMAIL_TOKEN_JSON")

    if not creds_json:
        raise ValueError("GMAIL_TOKEN_JSON not found")

    return Credentials.from_authorized_user_info(
        json.loads(creds_json),
        SCOPES,
    )


def gmail_service():
    creds = load_credentials()

    return build(
        "gmail",
        "v1",
        credentials=creds,
    )


def get_existing_labels(service):
    response = (
        service.users()
        .labels()
        .list(userId="me")
        .execute()
    )

    return response.get(
        "labels",
        []
    )


def ensure_labels_exist(service):
    existing = get_existing_labels(
        service
    )

    existing_names = {
        label["name"]
        for label in existing
    }

    for label_name in ALL_LABELS:

        if label_name in existing_names:
            print(
                f"✓ Label exists: {label_name}"
            )
            continue

        print(
            f"Creating label: {label_name}"
        )

        (
            service.users()
            .labels()
            .create(
                userId="me",
                body={
                    "name": label_name,
                    "labelListVisibility": "labelShow",
                    "messageListVisibility": "show",
                },
            )
            .execute()
        )


def get_label_map(service):
    labels = get_existing_labels(
        service
    )

    return {
        label["name"]: label["id"]
        for label in labels
    }


def apply_label(
    service,
    message_id,
    label_name,
):
    label_map = get_label_map(
        service
    )

    label_id = label_map.get(
        label_name
    )

    if not label_id:
        return

    (
        service.users()
        .messages()
        .modify(
            userId="me",
            id=message_id,
            body={
                "addLabelIds": [
                    label_id
                ]
            },
        )
        .execute()
    )


def remove_labels(
    service,
    message_id,
    label_names,
):
    label_map = get_label_map(
        service
    )

    remove_ids = []

    for label_name in label_names:

        label_id = label_map.get(
            label_name
        )

        if label_id:
            remove_ids.append(
                label_id
            )

    if not remove_ids:
        return

    (
        service.users()
        .messages()
        .modify(
            userId="me",
            id=message_id,
            body={
                "removeLabelIds":
                remove_ids
            },
        )
        .execute()
    )


def decode_base64(data):
    try:
        return (
            base64.urlsafe_b64decode(
                data
            )
            .decode(
                "utf-8",
                errors="ignore",
            )
        )

    except Exception:
        return ""


def html_to_text(html):
    try:
        soup = BeautifulSoup(
            html,
            "html.parser",
        )

        return soup.get_text(
            separator="\n"
        )

    except Exception:
        return html


def extract_body(payload):

    if "parts" in payload:

        for part in payload["parts"]:

            mime_type = part.get(
                "mimeType",
                ""
            )

            if mime_type == "text/plain":

                data = (
                    part.get(
                        "body",
                        {},
                    )
                    .get("data")
                )

                if data:
                    return decode_base64(
                        data
                    )

        for part in payload["parts"]:

            mime_type = part.get(
                "mimeType",
                ""
            )

            if mime_type == "text/html":

                data = (
                    part.get(
                        "body",
                        {},
                    )
                    .get("data")
                )

                if data:
                    html = decode_base64(
                        data
                    )

                    return html_to_text(
                        html
                    )

    data = (
        payload.get(
            "body",
            {},
        )
        .get("data")
    )

    if not data:
        return ""

    return decode_base64(
        data
    )


def extract_header(
    headers,
    name,
):
    for header in headers:

        if (
            header["name"].lower()
            == name.lower()
        ):
            return header["value"]

    return ""

def extract_email_address(sender):
    match = re.search(
        r"<([^>]+)>",
        sender,
    )

    if match:
        return match.group(1)

    return sender.strip()

def get_unprocessed_emails(
    service,
    max_results=10,
):
    query = (
        'is:unread '
        'in:inbox '
        '-label:"AI Processed"'
    )

    response = (
        service.users()
        .messages()
        .list(
            userId="me",
            q=query,
            maxResults=max_results,
        )
        .execute()
    )

    return response.get(
        "messages",
        []
    )


def get_message(
    service,
    message_id,
):
    return (
        service.users()
        .messages()
        .get(
            userId="me",
            id=message_id,
            format="full",
        )
        .execute()
    )

def create_draft(
    service,
    to_email,
    subject,
    body,
    thread_id=None,
):
    message = MIMEText(body)

    message["to"] = to_email

    if subject.lower().startswith(
        "re:"
    ):
        message["subject"] = subject
    else:
        message["subject"] = (
            f"Re: {subject}"
        )

    raw_message = (
        base64.urlsafe_b64encode(
            message.as_bytes()
        )
        .decode()
    )

    draft_body = {
        "message": {
            "raw": raw_message
        }
    }

    if thread_id:
        draft_body["message"][
            "threadId"
        ] = thread_id

    return (
        service.users()
        .drafts()
        .create(
            userId="me",
            body=draft_body,
        )
        .execute()
    )


def has_label(
    message,
    label_id,
):
    return (
        label_id
        in message.get(
            "labelIds",
            []
        )
    )