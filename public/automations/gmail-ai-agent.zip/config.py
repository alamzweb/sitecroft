GEMINI_MODEL = "gemini-2.5-flash"

CONFIDENCE_THRESHOLD = 80

SIGNATURE = "Muhammad Saad"

WORKFLOW_LABELS = [
    "To Respond",
    "Collaboration",
    "Meeting",
    "Marketing",
    "Cold Email",
    "Notification",
    "Review Manually",
]

SYSTEM_LABELS = [
    "AI Processed",
    "AI Draft Created",
]

ALL_LABELS = WORKFLOW_LABELS + SYSTEM_LABELS

EMAIL_ADDRESS = "alamzweb@gmail.com"