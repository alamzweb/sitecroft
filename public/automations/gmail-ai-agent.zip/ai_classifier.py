import json
import os

from google import genai

from config import (
    GEMINI_MODEL,
    CONFIDENCE_THRESHOLD,
    WORKFLOW_LABELS,
)


def get_client():
    api_key = os.getenv(
        "GEMINI_API_KEY"
    )

    if not api_key:
        raise ValueError(
            "GEMINI_API_KEY environment variable not found."
        )

    return genai.Client(
        api_key=api_key
    )


def build_prompt(
    sender,
    subject,
    body,
):
    return f"""
You are an expert email triage assistant.

Your job is to classify emails into EXACTLY ONE of these labels:

{json.dumps(WORKFLOW_LABELS)}

Classification rules:

To Respond:
The sender expects a reply, answer,
decision, quote, approval,
confirmation, action or response.

Collaboration:
Partnerships, sponsorships,
guest posts, podcast invitations,
interviews, affiliate opportunities,
joint ventures and creator outreach.

Meeting:
Meeting scheduling,
calendar invites,
rescheduling requests,
availability discussions,
calls and consultations.

Marketing:
Newsletters,
promotional emails,
product announcements,
launches,
educational marketing content,
platform updates,
community updates.

Cold Email:
Unsolicited outreach,
SEO services,
lead generation offers,
agency pitches,
sales emails,
generic business solicitations.

Notification:
Automated informational emails that do not require a reply.

Examples:
- Login verification codes
- Security alerts
- 2FA notifications
- Password reset emails
- Account warnings
- Billing notices
- Receipts
- Service notifications
- GitHub notifications
- Repository activity
- Google account alerts
- Platform account updates
- Automated system messages

Review Manually:
Legal matters,
contracts,
invoices,
financial matters,
unclear emails,
or low confidence classifications.

Rules:

1. Return EXACTLY one label.
2. Confidence must be an integer from 0 to 100.
3. needs_reply should be true only if Muhammad Saad should reasonably reply.
4. Return JSON only.
5. No markdown.
6. No code blocks.
7. No explanations outside JSON.
8. Sender address alone is NOT enough to determine the label.

Emails from:

noreply
no-reply
notification
notifications

can be either Marketing or Notification.

Notification examples:
- Security alerts
- Login verification codes
- 2FA setup or enforcement
- Password reset emails
- Account warnings
- Billing notices
- Service outages
- Account activity alerts
- Repository notifications
- GitHub, Google, Microsoft or platform account notices
- Automated messages requiring awareness but not a reply

Marketing examples:
- Newsletters
- Product updates
- Feature announcements
- Promotions
- Launches
- Educational content
- Community updates
- Re-engagement campaigns

Always classify based primarily on the email content and purpose, not the sender address.

Sender:
{sender}

Subject:
{subject}

Body:
{body[:5000]}

Return exactly:

{{
  "label": "Marketing",
  "confidence": 95,
  "needs_reply": false,
  "reason": "Short explanation"
}}
"""


def safe_fallback(
    reason="Gemini parsing failure",
):
    return {
        "label": "Review Manually",
        "confidence": 0,
        "needs_reply": False,
        "reason": reason,
    }


def classify_email(
    sender,
    subject,
    body,
):
    try:
        client = get_client()

        response = (
            client.models.generate_content(
                model=GEMINI_MODEL,
                contents=build_prompt(
                    sender,
                    subject,
                    body,
                ),
            )
        )

        raw_text = (
            response.text.strip()
        )

        print(
            "\nRAW GEMINI RESPONSE:"
        )
        print(raw_text)

        result = json.loads(
            raw_text
        )

    except Exception as e:
        return safe_fallback(
            str(e)
        )

    label = result.get(
        "label",
        "Review Manually",
    )

    confidence = int(
        result.get(
            "confidence",
            0,
        )
    )

    if label not in WORKFLOW_LABELS:
        label = (
            "Review Manually"
        )

    if (
        confidence
        < CONFIDENCE_THRESHOLD
    ):
        label = (
            "Review Manually"
        )

    result["label"] = label
    result["confidence"] = confidence

    return result
