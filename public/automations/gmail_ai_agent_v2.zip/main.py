import json
import time

from ai_classifier import classify_email
from config import (
    SYSTEM_LABELS,
    WORKFLOW_LABELS,
)
from draft_generator import generate_draft
from gmail_utils import (
    apply_label,
    create_draft,
    ensure_labels_exist,
    extract_body,
    extract_email_address,
    extract_header,
    get_message,
    get_unprocessed_emails,
    gmail_service,
    remove_labels,
)


def process_email(
    service,
    message_id,
):
    message = get_message(
        service,
        message_id,
    )

    payload = message["payload"]

    headers = payload["headers"]

    sender = extract_header(
        headers,
        "From",
    )

    subject = extract_header(
        headers,
        "Subject",
    )

    body = extract_body(
        payload
    )

    if not body or not body.strip():
        body = "[No readable email content]"

    print("\n" + "=" * 80)
    print("MESSAGE:", message_id)
    print("FROM:", sender)
    print("SUBJECT:", subject)

    classification = classify_email(
        sender,
        subject,
        body,
    )

    print("\nCLASSIFICATION:")
    print(
        json.dumps(
            classification,
            indent=2,
        )
    )

    label = classification[
        "label"
    ]

    remove_labels(
        service,
        message_id,
        WORKFLOW_LABELS,
    )

    apply_label(
        service,
        message_id,
        label,
    )

    apply_label(
        service,
        message_id,
        "AI Processed",
    )

    if (
        classification.get(
        "needs_reply",
        False,
        )
        and label != "Review Manually"
    ):

        print(
            "\nGenerating draft..."
        )

        draft_text = (
            generate_draft(
                label,
                sender,
                subject,
                body,
            )
        )

        print(
            "\nDRAFT PREVIEW:"
        )
        print("-" * 60)
        print(draft_text)
        print("-" * 60)

        create_draft(
            service=service,
            to_email=extract_email_address(
                sender
            ),
            subject=subject,
            body=draft_text,
            thread_id=message[
                "threadId"
            ],
        )

        apply_label(
            service,
            message_id,
            "AI Draft Created",
        )

        print(
            "✓ Draft created"
        )

    else:
        print(
            "✓ No draft needed"
        )


def main():
    service = gmail_service()

    ensure_labels_exist(
        service
    )

    emails = (
        get_unprocessed_emails(
            service,
            max_results=25,
        )
    )

    print(
        f"\nFound {len(emails)} email(s)\n"
    )

    if not emails:
        print(
            "No emails to process."
        )
        return

    for email in emails:

        try:
            process_email(
                service,
                email["id"],
            )

        except Exception as e:

            print(
                "\nERROR:"
            )
            print(e)

        time.sleep(12)
        continue

    print(
        "\nFinished processing emails."
    )


if __name__ == "__main__":
    main()
