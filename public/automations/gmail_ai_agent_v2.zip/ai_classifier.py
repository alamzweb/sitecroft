import json
import os

from google import genai

from config import (
    GEMINI_MODEL,
    CONFIDENCE_THRESHOLD,
    WORKFLOW_LABELS,
)


def get_client():
    api_key = os.getenv(
        "GEMINI_API_KEY"
    )

    if not api_key:
        raise ValueError(
            "GEMINI_API_KEY environment variable not found."
        )

    return genai.Client(
        api_key=api_key
    )


def build_prompt(
    sender,
    subject,
    body,
):
    return f"""
You are an expert email triage assistant.

Your job is to classify emails into EXACTLY ONE of these labels:

{json.dumps(WORKFLOW_LABELS)}

Classification rules:

Priority order:

When an email could reasonably fit multiple labels, choose the most specific label and follow this priority:

1. Review Manually
2. Collaboration
3. Meeting
4. To Respond
5. Notification
6. Marketing
7. Cold Email

To Respond:
The sender expects a reply, answer, quote, decision, approval, confirmation, action, or information.

Examples:

* Service inquiries
* Pricing requests
* Quote requests
* Customer questions
* Support requests
* Requests for information
* Follow-up questions
* Availability questions

Important:
Inbound questions from real people should strongly prefer To Respond rather than Marketing.

To Respond is the general category for reply-worthy emails.

If an email clearly belongs to Collaboration or Meeting, prefer those more specific labels.

Collaboration:
Emails where a person or organization wants to work together, partner, sponsor, integrate products, share revenue, publish guest content, appear on podcasts, co-market, or pursue mutually beneficial opportunities.

Examples:

* Partnership proposals
* Affiliate opportunities
* Sponsorship requests
* Guest posts
* Podcast invitations
* Interviews
* Joint ventures
* Creator outreach
* Community collaborations
* Product integrations
* Revenue-sharing discussions
* Co-marketing opportunities

IMPORTANT:

Partnership proposals, sponsorship requests, affiliate opportunities, guest posts, creator outreach, integrations, revenue-sharing opportunities, community collaborations, and joint ventures MUST be classified as Collaboration.

These emails are NOT Marketing even when unsolicited.

If another person or organization is proposing cooperation, mutual benefit, or partnership, ALWAYS choose Collaboration over Marketing.

Meeting:
Meeting scheduling,
calendar invites,
rescheduling requests,
availability discussions,
calls,
consultations,
Zoom meetings,
Google Meet invitations.

Marketing:
Promotional or informational content intended for many recipients.

Examples:

* Newsletters
* Product updates
* Feature announcements
* Promotions
* Launches
* Educational content
* Platform updates
* Community updates
* Release notes
* Re-engagement campaigns

Important:
Marketing emails usually do not expect a direct reply.

Do NOT classify partnership proposals, sponsorship requests, creator outreach, affiliate opportunities, or joint ventures as Marketing.

Cold Email:
Unsolicited outreach intended primarily to sell a product or service.

Examples:

* SEO services
* Lead generation offers
* Agency pitches
* Sales emails
* Generic business solicitations
* Link-building services
* Mass prospecting emails

Important:
Cold emails are primarily trying to sell something.

Notification:
Automated informational emails that do not require a reply.

Examples:

* Login verification codes
* Security alerts
* 2FA notifications
* Password reset emails
* Account warnings
* Billing notices
* Receipts
* Service notifications
* GitHub notifications
* Repository activity
* Platform account updates
* Automated system messages

Review Manually:
Legal matters, contracts, invoices, payments, financial matters, sensitive topics, unclear emails, or low-confidence classifications.

Rules:

1. Return EXACTLY one label.
2. Confidence must be an integer from 0 to 100.
3. needs_reply should be true only if a reasonable person would expect a reply.
4. Return JSON only.
5. No markdown.
6. No code blocks.
7. No explanations outside JSON.
8. Sender address alone is NOT enough to determine the label.
9. Always classify primarily based on the content and purpose of the email.
10. If the sender asks a question or requests information, strongly prefer To Respond.
11. If the sender proposes cooperation or mutual benefit, strongly prefer Collaboration.
12. Marketing emails generally do not expect replies.
13. Cold emails are primarily trying to sell something.
14. Contracts, invoices, payments, and legal matters should strongly prefer Review Manually.

Emails from:

noreply
no-reply
notification
notifications

can be either Marketing or Notification.

Always classify based primarily on the email content and purpose, not the sender address.

Sender:
{sender}

Subject:
{subject}

Body:
{body[:5000]}

Return exactly:

{{
  "label": "Marketing",
  "confidence": 95,
  "needs_reply": false,
  "reason": "Short explanation"
}}
"""


def safe_fallback(
    reason="Gemini parsing failure",
):
    return {
        "label": "Review Manually",
        "confidence": 0,
        "needs_reply": False,
        "reason": reason,
    }


def classify_email(
    sender,
    subject,
    body,
):
    try:
        client = get_client()

        response = (
            client.models.generate_content(
                model=GEMINI_MODEL,
                contents=build_prompt(
                    sender,
                    subject,
                    body,
                ),
            )
        )

        raw_text = (
            response.text.strip()
        )

        print(
            "\nRAW GEMINI RESPONSE:"
        )
        print(raw_text)

        result = json.loads(
            raw_text
        )

    except Exception as e:
        return safe_fallback(
            str(e)
        )

    label = result.get(
        "label",
        "Review Manually",
    )

    confidence = int(
        result.get(
            "confidence",
            0,
        )
    )

    if label not in WORKFLOW_LABELS:
        label = (
            "Review Manually"
        )

    if (
        confidence
        < CONFIDENCE_THRESHOLD
    ):
        label = (
            "Review Manually"
        )

    result["label"] = label
    result["confidence"] = confidence

    return result
