import os

from google import genai

from config import (
    GEMINI_MODEL,
    SIGNATURE,
)


def get_client():
    api_key = os.getenv(
        "GEMINI_API_KEY"
    )

    if not api_key:
        raise ValueError(
            "GEMINI_API_KEY not found."
        )

    return genai.Client(
        api_key=api_key
    )


def build_prompt(
    label,
    sender,
    subject,
    body,
):
    return f"""
You are writing an email draft for Muhammad Saad.

Tone:
Friendly professional. Avoid sounding robotic.

Write naturally.

Keep replies under 150 words unless the email requires more detail.

Important rules:

1. Keep replies concise.
2. Do not invent pricing.
3. Do not invent availability.
4. Ask questions when information is missing.
5. Sign only with:

{SIGNATURE}

6. If the sender is requesting:

- WordPress work
- Website development
- Landing page development
- Custom coding
- React development
- Next.js development
- n8n automation
- AI automation

then:

1. Thank them.
2. Ask for project requirements.
3. Mention my website sitecroftdev.dnnengineer.com.
4. Do NOT discuss pricing until requirements are known.

7. For collaboration requests:
   Ask for additional details before agreeing.

8. For meeting requests:
   Ask the sender for a few available time slots and timezone.

If the email already contains:

- Google Meet link
- Zoom link
- Teams link
- Calendar invite
- Meeting confirmation

then do NOT ask for scheduling information.

Instead acknowledge receipt and confirm that Muhammad Saad received the information.

9. Do not use markdown.

Email classification:
{label}

Sender:
{sender}

Subject:
{subject}

Original email:
{body[:6000]}

Write only the email body.
No explanations.
"""
    

def generate_draft(
    label,
    sender,
    subject,
    body,
):
    client = get_client()

    response = (
        client.models.generate_content(
            model=GEMINI_MODEL,
            contents=build_prompt(
                label,
                sender,
                subject,
                body,
            ),
        )
    )

    draft_text = (
        response.text.strip()
    )

    return draft_text
