from google_auth_oauthlib.flow import InstalledAppFlow

SCOPES = [
    "https://www.googleapis.com/auth/gmail.modify",
    "https://www.googleapis.com/auth/gmail.compose",
]

flow = InstalledAppFlow.from_client_secrets_file(
    "credentials.json",
    SCOPES,
)

flow.redirect_uri = "http://localhost"

auth_url, _ = flow.authorization_url(
    access_type="offline",
    prompt="consent",
)

print("\nOPEN THIS URL:\n")
print(auth_url)

code = input("\nPASTE AUTHORIZATION CODE HERE:\n")

flow.fetch_token(code=code)

creds = flow.credentials

with open("token.json", "w") as f:
    f.write(creds.to_json())

print("\nSUCCESS! token.json created.")